# Object

You can add OLE embeddings, such as Excel spreadsheets or PowerPoint presentations to the document by using ``addOLEObject`` method.

``` php
<?php

$section->addOLEObject($src, [$style]);
```