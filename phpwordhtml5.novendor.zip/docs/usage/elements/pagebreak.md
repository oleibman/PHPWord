# Page breaks

There are two ways to insert a page break, using the ``addPageBreak`` method or using the ``pageBreakBefore`` style of paragraph.

``` php
<?php

$section->addPageBreak();
```