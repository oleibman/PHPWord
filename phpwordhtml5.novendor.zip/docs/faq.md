# Frequently asked questions

## How contribute to PHPWord?
- Improve the documentation

