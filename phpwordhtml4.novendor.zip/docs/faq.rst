.. _faq:

Frequently asked questions
==========================

How contribute to PHPWord?
--------------------------
- Improve the documentation (`Sphinx Format <http://documentation-style-guide-sphinx.readthedocs.org/en/latest/index.html>`__)
